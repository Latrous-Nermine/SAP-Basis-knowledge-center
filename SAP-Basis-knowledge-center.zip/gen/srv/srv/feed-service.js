const cds = require('@sap/cds');
const FeedHandler = require('./handlers/FeedHandler');

module.exports = cds.service.impl(FeedHandler);